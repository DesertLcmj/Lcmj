<?php
/*
 *@Lcmj
 *
 *@Made by Desert
 *
 *@Build:2012-09-10
 *@Final:2012-09-14
 *
 *
 *@The main module of Lcmj
 */

class Lcmj_module {

    //初始化模型
    public function __construct()
    {
        $lcmj = new Lcmj_model();
    }

    //操作id
    protected $mid;
    protected $sid;

    //路由
    public function route()
    {
		if (!empty($_GET['mid']))
		{
			if ($_GET['mid'] == 'index' OR $_GET['mid'] == 'labs' OR $_GET['mid'] == 'micro' OR $_GET['mid'] == 'me')
			{
				$mid = $_GET['mid'];
			} else {
				$mid = 'index';
			}
		}

		if (!empty($_GET['sid']))
		{
			if (is_int($_GET['sid']))
			{
				$sid = $_GET['sid'];
			} else {
				$sid = 1;
			}
		}
        echo 'This is route'.$mid.'&nbsp'.$sid;
    }


    /*
     *@文章
     */

    //发表文章
    public function add_blog($title,$content,$label,$top)
    {
        $time = date("Y-m-d H:i:s");
        $result = $lcmj -> add_blog($title,$content,$label,$top,$time);
        return $result; 
    }

    //读取文章
    public function list_blog()
    {
    }

    //修改文章
    public function mod_blog()
    {
    }

    //删除文章
    public function del_blog()
    {
    }


    /*
     *@登陆
     */

    //登陆
    public function login($username,$passwd)
    {
        $username = $this->filter_login($username);
        $passwd = md5($this->filter_login($passwd));
        $result = $lcmj -> login($username,$passwd);
        if (!empty($result))
        {
            $row = mysql_fetch_array($result,MYSQL_ASSOC);

            $randnum = sha1(time());
            $username = $row['user'];
            $ip = $SERVER['REMOTE_ADDR'];
            $user_agent = $SERVER['HTTP_USER_AGENT'];
            $intime = date("Y-m-d H:i:s");
            $outtime = date("Y-m-d H:i:s");
            if ($Lcmj -> uselog($randnum,$username,$ip,$user_agent,$intime,$outime))
            {
                return $row;
            } else 
            {
                return false;
            }
        } else 
        {
            return false;
        }
    }

    //注销
    public function logout()
    {
        $time = date("Y-m-d H:m:s");
        $lcmj -> logout($time);
        session_destroy();

        //header(Location:'');
    }


    /*
     *安全
     */

    //过滤登陆数据
    private function filter_login($data)
    {
        return $data;
    }

    //过滤文章
    private funciton filter_blog($data);
    {
        return $data;
    }


}


/* End of file lcmj_module.php */
/* Location:./modules/lcmj_module.php */
