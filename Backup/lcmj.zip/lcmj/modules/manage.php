<?php
/*
 *@Lcmj
 *
 *@Made by Desert
 *
 *@Build:2012-09-13
 *@Final:2012-09-13
 *
 *
 *@The manage of Lcmj
 */

    include '../config/site_info.php';

    //判断是否已登录
    if (!empty($_SESSION['user']))
    {
	    if ($_SESSION['user'] != 'admin')
        {
            header(Location:'./login.php');

        }
    }
?>
<!DOCtype html>
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>Login--<?php echo $site_title; ?></title>

	<meta name="author" content="Desert" />
    <meta name="keywords" content="<?php echo $site_keywords; ?>" />
    <meta name="description" content="<?php echo $site_description; ?>" />
	
    <link type="text/css" href="<?php echo $site_url; ?>/views/style/index.css" rel="stylesheet" />
</head>

<body>
    <p>This is manage page</p>
</body>

</html>
