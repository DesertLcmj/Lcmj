<?php
/*
 *@Lcmj
 *
 *@Made by Desert
 *
 *@Build:2012-09-12
 *@Final:2012-09-15
 *
 *
 *@The login of Lcmj
 */

    include '../config/site_info.php';

    //判断是否已登录
    if (!empty($_SESSION['user']))
    {
	    if ($_SESSION['user'] == 1 OR $_SESSION['user'] ==2)
	    {
            //header(Location:'./manage.php');
        }
    }

    //验证登录
	if (!empty($_POST['submit']))
	{
        include '../config/database.php';
        include '../models/Lcmj_model.php';
        include './Lcmj_module.php';
        
		$login = new Lcmj_module();
        $result = $login -> login($_POST['username'],$_POST['password']);
        if (!empty($result))
        {
			$_SESSION['user'] = $result['power'];
			echo '<script>window.location = "manage.php"; alert("登录成功")</script>';
        } else {
			echo '<script>window.location = "manage.php"; alert("用户名或密码错误")</script>';
		}
	}
?>
<!DOCtype html>
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>Login--<?php echo $site_title; ?></title>

	<meta name="author" content="Desert" />
    <meta name="keywords" content="<?php echo $site_keywords; ?>" />
    <meta name="description" content="<?php echo $site_description; ?>" />
	
    <link type="text/css" href="<?php echo $site_url; ?>/views/style/index.css" rel="stylesheet" />
</head>

<body>
<form action="" method="post">
	<p>Username:<input type="text" name="username" size="12" value="<?php if (!empty($_POST['username'])) {echo $_POST['username']; } ?>" /></p>
	<p>Password:<input type="password" name="password" size="12" /></p>
    <p>CheckCode:<input type="text" name="checkcode" size="4" /></p>
	<p><input type="reset" name="reset" value="Resert" />&nbsp;&nbsp;<input type="submit" name="submit" value="Submit" /></p>
</body>

</html>
