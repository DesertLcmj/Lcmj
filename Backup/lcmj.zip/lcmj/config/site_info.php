<?php
/*
 *@Lcmj
 *
 *@Made by Desert
 *
 *@Build:2012-09-12
 *@Final:2012-09-12
 *
 *
 *@The site info file of Lcmj
 */

$site_url = 'http://127.0.0.1/lcmj';
$site_title = '良辰美景--Desert Remember';
$site_keywords = '良辰美景,Desert,Remember,小曹,8023,娃娃,web前端,Javascript,PHP,C,开源';
$site_description = 'Desert Remember';
$site_h1 = '良辰美景';
$site_h2 = 'Desert Remember';
$site_copy = '&copy;&nbsp;2012&nbsp;&nbsp;<a href="index.php">良辰美景</a>';


/* End of the file site_info.php */
/* Location:./config/site_info.php */
