<?php
/*
 *@Lcmj
 *
 *@Made by Desert
 *
 *@Build:2012-09-12
 *@Final:2012-09-12
 *
 *
 *@The database config of Lcmj
 */

define('DB_HOST','localhost');
define('DB_PORT','3306');
define('DB_USER','root');
define('DB_PASSWD','root');
define('DB_NAME','Lcmj');
define('DB_PRE','Lcmj_');


/* End of the file database.php */
/* Location:./config/database.php */
