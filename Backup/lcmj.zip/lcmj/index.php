<?php
/*
 *@Lcmj
 *
 *@Made by Desert
 *
 *@Build:2012-09-12
 *@Final:2012-09-13
 *
 *
 *@The index of Lcmj
 */

    include './modules/Lcmj_module.php';
    $index = new Lcmj_module();
    $index -> route();


/* End of the file index.php */
/* Location:./index.php */
