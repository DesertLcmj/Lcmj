<?php
/*
 *@Lcmj
 *
 *@Made by Desert
 *
 *@Build:2012-09-12
 *@Final:2012-09-15
 *
 *
 *@The main model of Lcmj
 */

class Lcmj_model {

    //初始化数据库
    public function __construct()
    {
        $dbc = mysql_connect(DB_HOST,DB_USER,DB_PASSWD);
        mysql_select_db(DB_NAME);
    }


    /*
     *@文章
     */

    //发表文章
    public function add_blog($title,$content,$label,$top,$time)
    {
        $table = DB_NAME.'blog';
        $query = "INSERT INTO $table (title,content,label,top,time) VALUES ('$title','$content','$label','$top','$time')";
        $result = mysql_query($query);
        return $result;
    }


    /*
     *@登陆
     */

    //登陆
    public function login($username,$passwd)
    {
        $table = DB_PRE.'user';
        $query = "SELECT power FROM $table WHERE username = '$username' AND passwd = '$passwd'";
        $result = mysql_query($query);
        return $result;
    }

    //登陆日志
    public function userlog($randnum,$username,$ip,$username,$intime,$outtime)
    {
        $query = "SELECT ";
    }

    //注销
    public function logout($time)
    {
        $query = "UPDATE lcmj_userlog SET time = '$time'";
        $result = mysql_query($query);
        return $result;
    }

}


/* End of the file lcmj_model.php */
/* Location:./models/lcmj_model.php */
